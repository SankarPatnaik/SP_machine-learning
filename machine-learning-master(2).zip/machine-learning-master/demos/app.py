import util


if __name__ == "__main__":
    n = 10
    print(n, util.is_prime(n))